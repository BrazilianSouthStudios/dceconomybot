const { SlashCommandBuilder } = require('discord.js');
const db = require('../db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Mostra seu saldo')
    .addStringOption(opt => opt.setName('currency').setDescription('Moeda (padrão: gold)').setRequired(false)),
  async execute(interaction) {
    const userId = interaction.user.id;
    const currency = interaction.options.getString('currency') || 'gold';
    const bal = db.getBalance(userId, currency);
    await interaction.reply({ content: `💰 ${interaction.user.username}, você tem **${bal} ${currency}**.`, ephemeral: true });
  }
};