const fs = require('fs');
const path = './user_data.json';

const db = {
  readData: () => {
    if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));
    return JSON.parse(fs.readFileSync(path));
  },

  writeData: (data) => {
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
  },

  addBalance: (userId, currency, amount) => {
    let data = db.readData();
    if (!data[userId]) data[userId] = {};
    if (!data[userId][currency]) data[userId][currency] = 0;
    data[userId][currency] += amount;
    db.writeData(data);
  },

  getBalance: (userId, currency) => {
    let data = db.readData();
    if (!data[userId] || !data[userId][currency]) return 0;
    return data[userId][currency];
  }
};

module.exports = db;
