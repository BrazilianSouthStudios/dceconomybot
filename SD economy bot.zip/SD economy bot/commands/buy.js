const { SlashCommandBuilder } = require('discord.js');
const db = require('../db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('buy')
    .setDescription('Compra um item da loja')
    .addStringOption(opt => opt.setName('item').setDescription('ID do item').setRequired(true)),
  async execute(interaction) {
    const userId = interaction.user.id;
    const itemId = interaction.options.getString('item');
    try {
      const item = db.buyItem(userId, itemId);
      await interaction.reply(`Você comprou **${item.name}** por **${item.price} ${item.currency}**.`);
    } catch (err) {
      await interaction.reply({ content: `Erro: ${err.message}`, ephemeral: true });
    }
  }
};