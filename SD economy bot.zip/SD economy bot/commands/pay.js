const { SlashCommandBuilder } = require('discord.js');
const db = require('../db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pay')
    .setDescription('Paga alguém')
    .addUserOption(opt => opt.setName('user').setDescription('Quem recebe').setRequired(true))
    .addIntegerOption(opt => opt.setName('amount').setDescription('Valor').setRequired(true))
    .addStringOption(opt => opt.setName('currency').setDescription('Moeda').setRequired(false)),
  async execute(interaction) {
    const from = interaction.user.id;
    const toUser = interaction.options.getUser('user');
    const to = toUser.id;
    const amount = interaction.options.getInteger('amount');
    const currency = interaction.options.getString('currency') || 'gold';
    if (to === from) return interaction.reply({ content: 'Você não pode pagar você mesmo.', ephemeral: true });
    if (amount <= 0) return interaction.reply({ content: 'Valor inválido.', ephemeral: true });
    try {
      db.transfer(from, to, currency, amount);
      await interaction.reply(`${interaction.user.username} pagou ${toUser.username} **${amount} ${currency}**.`);
    } catch (err) {
      await interaction.reply({ content: `Erro: ${err.message}`, ephemeral: true });
    }
  }
};