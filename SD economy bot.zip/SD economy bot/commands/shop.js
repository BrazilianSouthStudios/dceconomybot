const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shop')
    .setDescription('Mostra a loja'),
  async execute(interaction) {
    const items = db.listShop();
    if (items.length === 0) return interaction.reply('Loja vazia.');
    const embed = new EmbedBuilder()
      .setTitle('Loja do servidor')
      .setDescription('Use /buy <id> pra comprar um item')
      .setFooter({ text: 'Ex: /buy starter_pack' });
    for (const it of items) {
      embed.addFields({ name: `${it.name} (${it.id})`, value: `${it.price} ${it.currency} — ${it.description}` });
    }
    await interaction.reply({ embeds: [embed] });
  }
};