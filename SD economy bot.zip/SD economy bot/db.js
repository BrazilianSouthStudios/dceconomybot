const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);

const db = new Database(path.join(dataDir, 'economy.db'));

db.exec(`
CREATE TABLE IF NOT EXISTS balances (
  user_id TEXT NOT NULL,
  currency TEXT NOT NULL,
  amount INTEGER NOT NULL,
  PRIMARY KEY (user_id, currency)
);
CREATE TABLE IF NOT EXISTS shop (
  id TEXT PRIMARY KEY,
  name TEXT,
  price INTEGER,
  currency TEXT,
  description TEXT
);
`);

const seedCount = db.prepare('SELECT COUNT(*) as c FROM shop').get().c;
if (seedCount === 0) {
  const insert = db.prepare('INSERT INTO shop (id, name, price, currency, description) VALUES (?, ?, ?, ?, ?)');
  insert.run('starter_pack', 'Starter Pack', 100, 'gold', 'Um pack inicial pra começar');
  insert.run('vip_role', 'VIP Role', 1000, 'gold', 'Role VIP — entrega manual');
}

module.exports = {
  getBalance(userId, currency = 'gold') {
    const row = db.prepare('SELECT amount FROM balances WHERE user_id = ? AND currency = ?').get(userId, currency);
    return row ? row.amount : 0;
  },
  setBalance(userId, currency = 'gold', amount = 0) {
    const exists = db.prepare('SELECT 1 FROM balances WHERE user_id = ? AND currency = ?').get(userId, currency);
    if (exists) db.prepare('UPDATE balances SET amount = ? WHERE user_id = ? AND currency = ?').run(amount, userId, currency);
    else db.prepare('INSERT INTO balances (user_id, currency, amount) VALUES (?, ?, ?)').run(userId, currency, amount);
  },
  addBalance(userId, currency = 'gold', delta = 0) {
    const cur = this.getBalance(userId, currency);
    if (cur === 0) this.setBalance(userId, currency, delta);
    else db.prepare('UPDATE balances SET amount = amount + ? WHERE user_id = ? AND currency = ?').run(delta, userId, currency);
  },
  transfer(fromId, toId, currency = 'gold', amount) {
    const fromBal = this.getBalance(fromId, currency);
    if (fromBal < amount) throw new Error('Saldo insuficiente');
    const tx = db.transaction((f, t, c, a) => {
      db.prepare('UPDATE balances SET amount = amount - ? WHERE user_id = ? AND currency = ?').run(a, f, c);
      const tRow = db.prepare('SELECT amount FROM balances WHERE user_id = ? AND currency = ?').get(t, c);
      if (tRow) db.prepare('UPDATE balances SET amount = amount + ? WHERE user_id = ? AND currency = ?').run(a, t, c);
      else db.prepare('INSERT INTO balances (user_id, currency, amount) VALUES (?, ?, ?)').run(t, c, a);
    });
    tx(fromId, toId, currency, amount);
  },
  listShop() {
    return db.prepare('SELECT id, name, price, currency, description FROM shop').all();
  },
  buyItem(userId, itemId) {
    const row = db.prepare('SELECT * FROM shop WHERE id = ?').get(itemId);
    if (!row) throw new Error('Item não existe');
    const bal = this.getBalance(userId, row.currency);
    if (bal < row.price) throw new Error('Saldo insuficiente');
    db.prepare('UPDATE balances SET amount = amount - ? WHERE user_id = ? AND currency = ?').run(row.price, userId, row.currency);
    return row;
  }
};