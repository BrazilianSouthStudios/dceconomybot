const { Client, GatewayIntentBits } = require("discord.js");
const fs = require("fs");

// Banco de dados simples em JSON
const dbFile = "./banco.json";
let banco = fs.existsSync(dbFile) ? JSON.parse(fs.readFileSync(dbFile)) : {};

// Cria o cliente
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

// Prefixo dos comandos
const prefix = "$";

// Whitelist de servidores
const allowedGuilds = [
  'placeholderserver', // main server
  'placeholderserver', // another server
  'placeholderserver'  // more one
];

function economiaAtiva(guildId) {
  return allowedGuilds.includes(guildId);
}

// Função para salvar banco
function salvarBanco() {
  fs.writeFileSync(dbFile, JSON.stringify(banco, null, 2));
}

client.on("messageCreate", (msg) => {
  if (!msg.content.startsWith(prefix) || msg.author.bot) return;

  const args = msg.content.slice(prefix.length).trim().split(/ +/);
  const comando = args.shift().toLowerCase();

  // === SALDO ===
  if (comando === "saldo") {
    if (!economiaAtiva(msg.guild.id)) return msg.reply("❌ Comandos de economia estão desativados neste servidor.");
    if (!banco[msg.author.id]) banco[msg.author.id] = { saldo: 0, historico: [] };
    msg.reply(`💰 Teu saldo é: P$${banco[msg.author.id].saldo}.`);
  }

  // === ADD ===
  if (comando === "add") {
    if (!economiaAtiva(msg.guild.id)) return msg.reply("❌ Comandos de economia estão desativados neste servidor.");
    if (!msg.member.permissions.has("Administrator")) return msg.reply("Sem permissão!");
    let user = msg.mentions.users.first();
    let valor = parseInt(args[1]);
    if (!user || isNaN(valor)) return msg.reply("Uso: !add @user 100");

    if (!banco[user.id]) banco[user.id] = {};
    if (!banco[user.id].saldo) banco[user.id].saldo = 0;
    if (!banco[user.id].historico) banco[user.id].historico = [];

    banco[user.id].saldo += valor;
    banco[user.id].historico.push(`💰 Add: +${valor} prátuns`);
    salvarBanco();
    msg.reply(`Adicionado 💰 P$${valor} para ${user.username}.`);
  }

  // === CHANGE ===
  if (comando === "change") {
    if (!economiaAtiva(msg.guild.id)) return msg.reply("❌ Comandos de economia estão desativados neste servidor.");
    if (!msg.member.permissions.has("Administrator")) return msg.reply("Sem permissão!");
    let user = msg.mentions.users.first();
    let valor = parseInt(args[1]);
    if (!user || isNaN(valor)) return msg.reply("Uso: !change @user 100");

    if (!banco[user.id]) banco[user.id] = {};
    if (!banco[user.id].saldo) banco[user.id].saldo = 0;
    if (!banco[user.id].historico) banco[user.id].historico = [];

    banco[user.id].saldo = valor;
    banco[user.id].historico.push(`⚡ Change: saldo definido para ${valor} prátuns`);
    salvarBanco();
    msg.reply(`💰 O saldo de ${user.username} agora é P$${valor}.`);
  }

  // === REMOVE ===
  if (comando === "remove") {
    if (!economiaAtiva(msg.guild.id)) return msg.reply("❌ Comandos de economia estão desativados neste servidor.");
    if (!msg.member.permissions.has("Administrator")) return msg.reply("Sem permissão!");
    let user = msg.mentions.users.first();
    let valor = parseInt(args[1]);
    if (!user || isNaN(valor)) return msg.reply("Uso: !remove @user 100");

    if (!banco[user.id]) banco[user.id] = {};
    if (!banco[user.id].saldo) banco[user.id].saldo = 0;
    if (!banco[user.id].historico) banco[user.id].historico = [];

    banco[user.id].saldo -= valor;
    if (banco[user.id].saldo < 0) banco[user.id].saldo = 0;
    banco[user.id].historico.push(`💸 Remove: -${valor} prátuns`);
    salvarBanco();
    msg.reply(`💸 ${valor} prátuns foram removidos do saldo de ${user.username}.`);
  }

  // === PAGAR ===
  if (comando === "pagar") {
    if (!economiaAtiva(msg.guild.id)) return msg.reply("❌ Comandos de economia estão desativados neste servidor.");
    let user = msg.mentions.users.first();
    let valor = parseInt(args[1]);
    if (!user || isNaN(valor)) return msg.reply("Uso: !pagar @user 100");

    if (!banco[msg.author.id]) banco[msg.author.id] = { saldo: 0, historico: [] };
    if (banco[msg.author.id].saldo < valor) return msg.reply("Saldo insuficiente!");
    if (!banco[user.id]) banco[user.id] = { saldo: 0, historico: [] };

    banco[msg.author.id].saldo -= valor;
    banco[user.id].saldo += valor;

    banco[msg.author.id].historico.push(`💸 Pagou ${valor} prátuns para ${user.username}`);
    banco[user.id].historico.push(`💰 Recebeu ${valor} prátuns de ${msg.author.username}`);

    salvarBanco();
    msg.reply(`Você pagou 💰 P$${valor} para ${user.username}.`);
  }

  // === TRABALHAR ===
  if (comando === "trabalhar") {
    if (!economiaAtiva(msg.guild.id)) return msg.reply("❌ Comandos de economia estão desativados neste servidor.");
    if (!banco[msg.author.id]) banco[msg.author.id] = { saldo: 0, lastWork: 0, historico: [] };
    let agora = Date.now();
    if (agora - (banco[msg.author.id].lastWork || 0) < 6 * 60 * 60 * 1000) {
      let tempo = Math.ceil((6 * 60 * 60 * 1000 - (agora - banco[msg.author.id].lastWork)) / 1000 / 60);
      return msg.reply(`⚠️ Você já trabalhou recentemente! Tente de novo em ${tempo} minutos.`);
    }
    let ganho = 0;
    banco[msg.author.id].saldo += ganho;
    banco[msg.author.id].lastWork = agora;
    banco[msg.author.id].historico.push(`⚒️ Work: +${ganho} prátuns`);
    salvarBanco();
    msg.reply(`⚒️ Por hora, o comando de trabalho está desativado para esse servidor.`);
  }

  // === BOLSAFAMILIA ===
  if (comando === "bolsafamilia") {
    if (!economiaAtiva(msg.guild.id)) return msg.reply("❌ Comandos de economia estão desativados neste servidor.");
    if (!banco[msg.author.id]) banco[msg.author.id] = { saldo: 0, lastDaily: 0, historico: [] };
    let agora = Date.now();
    if (agora - (banco[msg.author.id].lastDaily || 0) < 24 * 60 * 60 * 1000) {
      let tempo = Math.ceil((24 * 60 * 60 * 1000 - (agora - banco[msg.author.id].lastDaily)) / 1000 / 60);
      return msg.reply(`⚠️ Você já coletou seu bolsa família hoje! Tente de novo em ${tempo} minutos.`);
    }
    let ganho = 100;
    banco[msg.author.id].saldo += ganho;
    banco[msg.author.id].lastDaily = agora;
    banco[msg.author.id].historico.push(`🎁 Daily: +${ganho} prátuns`);
    salvarBanco();
    msg.reply(`🎁 Tu coletou teu auxílio de ${ganho} prátuns!`);
  }

  // === RANKING ===
  if (comando === "ranking") {
    if (!economiaAtiva(msg.guild.id)) return msg.reply("❌ Comandos de economia estão desativados neste servidor.");
    let ranking = Object.entries(banco)
        .sort((a, b) => (b[1].saldo || 0) - (a[1].saldo || 0))
        .slice(0, 5)
        .map(([id, data], index) => `${index + 1}. <@${id}> - ${data.saldo || 0}`);
    msg.reply(`🏆 Ranking de moedas:\n${ranking.join("\n")}`);
  }

  // === EXTRATO ===
  if (comando === "extrato") {
    if (!economiaAtiva(msg.guild.id)) return msg.reply("❌ Comandos de economia estão desativados neste servidor.");
    if (!banco[msg.author.id]) banco[msg.author.id] = { saldo: 0, historico: [] };
    let historico = banco[msg.author.id].historico.slice(-10); // últimos 10 registros
    if (historico.length === 0) return msg.reply("📄NUBank: Você ainda não realizou transações.");
    msg.reply(`📄NUBank: Últimas transações:\n${historico.join("\n")}`);
  }

  // === CASSINO ===
  if (comando === "cassino") {
    if (!economiaAtiva(msg.guild.id)) return msg.reply("❌ Comandos de economia estão desativados neste servidor.");
    let valor = parseInt(args[0]);
    if (!valor || isNaN(valor)) return msg.reply("Uso: !cassino <valor>");
    if (!banco[msg.author.id]) banco[msg.author.id] = { saldo: 0, historico: [] };
    if (banco[msg.author.id].saldo < valor) return msg.reply("Saldo insuficiente!");

    let ganhou = Math.random() < 0.1; // 10% de chance
    if (ganhou) {
        banco[msg.author.id].saldo += valor;
        banco[msg.author.id].historico.push(`🎰 Casino: +${valor} moedas`);
        msg.reply(`🎰 Sorte... Você ganhou 💰 ${valor} prátuns.. Eba.`);
    } else {
        banco[msg.author.id].saldo -= valor;
        banco[msg.author.id].historico.push(`🎰 Casino: -${valor} moedas`);
        msg.reply(`🎰 Que azar! Você perdeu 💰 ${valor} prátuns. Tenta de novo!`);
    }
    salvarBanco();
  }

  // === Tobi/Ping ===
  if (comando === "tobi") {
    msg.reply("é um viado");
  }
});

client.login("DISCORD BOT TOKEN HERE");
